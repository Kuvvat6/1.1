﻿using System;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество строк матрицы: ");
            int row = Int32.Parse(Console.ReadLine());
            Console.Write("Введите количество столбцов матрицы: ");
            int col = Int32.Parse(Console.ReadLine());
            if (row < 1 || col < 1)
            {
                Console.WriteLine("Размеры матрицы не могут быть < 1");
                return;
            }
            int[,] matrix = createMatrix(row, col);
            int maxValue = solution(matrix);
            Console.WriteLine("Исходная матрица:");
            printMatrix(matrix);
            Console.WriteLine("Максимум из всех минимальных элементов по столбцам: " + maxValue);
        }

        static int[,] createMatrix(int row, int col)
        {
            int[,] matrix = new int[row, col];
            Console.WriteLine("Введите значения матрицы: ");
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    matrix[i, j] = Int32.Parse(Console.ReadLine());
                }
                Console.WriteLine();
            }

            return matrix;
        }        
        
        static void printMatrix(int[,] matrix) {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(matrix[i, j] + "\t");
                    
                }
                Console.WriteLine();
            }
        }

        static int solution(int[,] matrix)
        {
            int maxValueOfMin = matrix[0, 0];
            
            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                int minValue = matrix[0, j];
                
                for (int i = 1; i < matrix.GetLength(0); i++)
                {
                    if (minValue > matrix[i, j])
                    {
                        minValue = matrix[i, j];
                    }
                }
                
                if (maxValueOfMin < minValue)
                {
                    maxValueOfMin = minValue;
                }
            }

            return maxValueOfMin;
        }
    }
}